class Prenda:
    tipo = ''

    def __init__(self, marca, color, talla):
        self.marca = marca
        self.color = color
        self.talla = talla
