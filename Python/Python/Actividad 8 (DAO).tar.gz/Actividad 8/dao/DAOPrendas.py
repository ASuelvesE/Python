class DAOPrendas:

    def ver(self):
        print("not yet implemented")